If you use this program, please cite the following paper:
Chunxu Xu, Tuanfeng Y. Wang, Yong-Jin Liu, Ligang Liu, Ying He (2015) 
Fast wavefront propagation (FWP) for computing exact geodesic distances on meshes.
IEEE Transactions on Visualization and Computer Graphics, 2015
DOI:10.1109/TVCG.2015.2407404
http://ieeexplore.ieee.org/xpl/articleDetails.jsp?arnumber=7050361&filter%3DAND%28p_IS_Number%3A4359476%29


USAGE:

-alg [algorithm]: 0 to 1 represent:
        0: MMP
        1: FWP-MMP
        2: ICH
        3: FWP-CH

-m [meshFile]: input model file.

-s [src0~srcN]: indices of sources.

-d [dst]: index of destination (not available for Fast Marching Methods).

-o [outputModelFile]: output model with scaled geodesic distance as texture coordinates of each vertex.

Examples:

1) use MMP, pick vertex 0, 1000, 2000 on model bunny.obj as sources and construct the path to vertex 10000:
FWP.exe -alg 0 -m bunny.obj -s 0 1000 2000 -d 10000

2) use FWP-MMP, pick vertex 0, 1000, 2000 on model bunny.obj as sources and construct the path to vertex 10000:
FWP.exe -alg 1 -m bunny.obj -s 0 1000 2000 -d 10000

2) use FWP-CH, pick vertex 1000 on model lucy.obj as source and output the textured model:
FWP.exe -alg 3 -m lucy.obj -s 1000 -o lucy.out.obj